const btn_ready = document.querySelector('#btn_ready');

btn_ready.addEventListener('click', function (e) {

    window.close();
})
