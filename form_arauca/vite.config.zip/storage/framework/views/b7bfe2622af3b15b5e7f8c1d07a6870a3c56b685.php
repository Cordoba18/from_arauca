<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="<?php echo e(asset('storage/imgs/logo.jpeg')); ?>" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>Participantes Totales</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/participants.css']); ?>
</head>

<body style="background-image: url(<?php echo e(asset('storage/imgs/FONDO.png')); ?>)">
<?php echo csrf_field(); ?>
    <div class="container">

        <div class="container_code">

            <h1>INGRESE EL CODIGO DE VALIDACIÓN</h1>
            <input type="number" placeholder="Ingrese el codigo" id="code_validation">
            <button id="btn_validar">VALIDAR</button>
        </div>

        <div class="container_participants" hidden>

            <h1>PARTICIPANTES</h1>

            <div class="table_participants">
                <table class="table">
                    <thead>
                        <th>ID</th>
                        <th>NOMBRE</th>
                        <th>NIT</th>
                        <th>TÉLEFONO</th>
                        <th>BARRIO/VEREDA</th>
                        <th>CIUDAD</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($p->id); ?></td>
                            <td><?php echo e($p->name); ?></td>
                            <td><?php echo e($p->nit); ?></td>
                            <td><?php echo e($p->phone); ?></td>
                            <td><?php echo e($p->neighborhood); ?></td>
                            <td><?php echo e($p->city); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <center><a href="<?php echo e(route('home.get_participants')); ?>" class="btn btn-success">DESCARGAR EXCEL</a></center>
        </div>
    </div>

</body>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/participants.js']); ?>
</html>
<?php /**PATH C:\xampp\htdocs\from_arauca\form_arauca\resources\views/shows/show_participants_arauca.blade.php ENDPATH**/ ?>