<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="<?php echo e(asset('storage/imgs/logo.jpeg')); ?>" type="image/x-icon">
    <title>Formulario de arauca</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/form.css']); ?>
</head>
<body style="background-image: url(<?php echo e(asset('storage/imgs/FONDO.png')); ?>)">

    <div class="container_form" >
        <div class="container_form_img">
            <img src="<?php echo e(asset('storage/imgs/TEXTO.png')); ?>" alt="">
        </div>
        <form id="form" action="<?php echo e(route('home.save_participant')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <label >Nombre</label>
            <input type="text" name="name" id="name" placeholder="Ingresa tu nombre" required>
            <label >Cedula</label>
            <input type="number" name="nit" id="nit" placeholder="Ingresa tu Cedula" required>
            <label>Ciudad</label>
            <select name="city" id="city" required>

                <?php $__currentLoopData = $citys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($c->id); ?>"><?php echo e($c->city); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label>Barrio/vereda</label>
            <select name="neighborhood" id="neighborhood" required>
                <option value="">Seleccione un barrio o vereda</option>
                <?php $__currentLoopData = $neighborhoods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($n->id); ?>"><?php echo e($n->neighborhood); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <label >Télefono</label>
            <input type="number" name="phone" id="phone" placeholder="Ingresa tu télefono" required>
            <div class="container_tyc">
            <input type="checkbox" id="myCheckbox" name="check_tyc" required>
           <a href="<?php echo e(route('home.terminos_condiciones')); ?>" target="_blank"><label>Aceptar terminos y condiciones</label></a>
        </div>
            <p class="message_error"></p>
            <div class="container_form_button">
            <button id="btn_register">REGISTRARSE</button>
        </div>
        </form>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
   <?php echo app('Illuminate\Foundation\Vite')(['resources/js/home.js']); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\from_arauca\form_arauca\resources\views/welcome.blade.php ENDPATH**/ ?>