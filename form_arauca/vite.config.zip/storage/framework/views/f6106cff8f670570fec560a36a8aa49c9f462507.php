<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="<?php echo e(asset('storage/imgs/logo.jpeg')); ?>" type="image/x-icon">
    <title>Participante inscrito</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/show.css']); ?>
</head>

<body

style="background-image: url(<?php echo e(asset('storage/imgs/FONDO.png')); ?>)">
<?php if($participant): ?>


<div class="container_confeti">
    <img src="<?php echo e(asset('storage/imgs/confeti.gif')); ?>" alt="">
</div>
<?php endif; ?>
    <div class="container_show">

        <div class="container_form_info_particapant">
            <div class="container_form_img">
                <?php if(!$participant): ?>
                <?php else: ?>
                <img src="<?php echo e(asset('storage/imgs/CONFIRMACION_REGISTRO.png')); ?>" alt="">
                <?php endif; ?>

            </div>
            <div class="container_form_into">
                <?php if(!$participant): ?>
                <h1>No eres un partipante</h1>
                <?php else: ?>
                <h1><?php echo e($participant->name); ?></h1>
                <p> NIT <?php echo e($participant->nit); ?></p>
                <?php endif; ?>

            </div>
        </div>
    </div>


</body>

</html>
<?php /**PATH C:\xampp\htdocs\from_arauca\form_arauca\resources\views/shows/show_participant.blade.php ENDPATH**/ ?>